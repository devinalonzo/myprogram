To install...

1. Copy the files to your system.
2. Register SignOn.dll by double-clicking the file or by running

   regsvr32 SignOn.dll

From a command line.
